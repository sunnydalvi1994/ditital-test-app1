import{j as t}from"./index-CN90tRrT.js";function n(){return t.jsx("div",{children:"SanctionLetter"})}export{n as default};
